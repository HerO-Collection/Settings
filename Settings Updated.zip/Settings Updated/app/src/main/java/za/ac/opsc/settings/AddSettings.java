package za.ac.opsc.settings;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddSettings extends AppCompatActivity {
    EditText editText;
    Button button;
    ListView listView;

    ArrayList<String> arrayList;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_settings);
        editText = findViewById(R.id.veri);
        button = findViewById(R.id.addButton);
        listView = findViewById(R.id.addList);

        arrayList = new ArrayList<>();
        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(adapter);

        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                String YeniVeri = editText.getText().toString();
                arrayList.add(YeniVeri);
                adapter.notifyDataSetChanged();
                editText.setText(" ");
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                Toast.makeText(AddSettings.this, "" + parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
            }
        });

    }
}