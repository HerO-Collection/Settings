package za.ac.opsc.settings;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.widget.RelativeLayout;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;
public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(toolbar);

        RelativeLayout relative1 = (RelativeLayout) findViewById(R.id.add_settings);
        relative1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //you can pass image & text over here using putExtra(
                openAddSettings();
            }
        });
        RelativeLayout relative2 = (RelativeLayout) findViewById(R.id.barChart);
        relative2.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                openViewGSettings();
            }
        });
        RelativeLayout relative3 = (RelativeLayout) findViewById(R.id.displayG_vfsettings);
        relative3.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                openDisplayGVisualSettings();
            }
        });
        RelativeLayout relative4 = (RelativeLayout) findViewById(R.id.view_dbsettings);
        relative4.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                openViewdbSettings();
            }
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

        }
    }
@Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
}
    public void openAddSettings(){
        Intent intent = new Intent(this, AddSettings.class);
        startActivity(intent);
    }
    public void openViewGSettings(){
        Intent intent = new Intent(this, ViewGSettings.class);
        startActivity(intent);
    }
    public void openDisplayGVisualSettings(){
        Intent intent = new Intent(this, DisplayGVisualSettings.class);
        startActivity(intent);
    }

}