package za.ac.opsc.settings;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class ViewdbSettings extends Activity {

    Button btn_LogIn;
    TextInputEditText text1, text2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewdb_settings);
        setContentView(R.layout.activity_viewdb_settings);
        btn_LogIn = (Button) findViewById(R.id.btn_LogIn);
        text1 = (TextInputEditText) findViewById(R.id.et_email);
        text2 = (TextInputEditText) findViewById(R.id.et_password);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo!=null && networkInfo.isConnected()){
            text1.setVisibility(View.INVISIBLE);
            text2.setVisibility(View.INVISIBLE);
        }
        else {
            btn_LogIn.setEnabled(false);
        }
    }
    public void et_password(View view ){
        startActivity(new Intent(this,SignIn.class));
    }

    }
